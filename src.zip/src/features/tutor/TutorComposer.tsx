"use client";

import { useRef } from "react";
import { Paperclip, Send } from "lucide-react";
import { Button } from "@/components/ui/button";

const quickActions = ["Explicar", "Resumir", "Flashcards", "Exercícios"];

export function TutorComposer({ draft, onDraftChange, onSend }: { draft: string; onDraftChange: (value: string) => void; onSend: () => void }) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const updateDraft = (value: string) => {
    onDraftChange(value);
    const textarea = textareaRef.current;
    if (textarea) {
      textarea.style.height = "auto";
      textarea.style.height = `${Math.min(textarea.scrollHeight, 180)}px`;
    }
  };

  return (
    <div className="mt-5">
      <div className="mb-3 flex flex-wrap gap-2" aria-label="Ações rápidas">
        {quickActions.map((action) => <Button key={action} type="button" size="sm" variant="outline" onClick={() => updateDraft(`${action} este tema`)}>{action}</Button>)}
      </div>
      <form className="rounded-xl border bg-card p-2 shadow-sm" onSubmit={(event) => { event.preventDefault(); onSend(); }}>
        <textarea ref={textareaRef} aria-label="Mensagem para o Tutor IA" value={draft} onChange={(event) => updateDraft(event.target.value)} placeholder="Pergunte sobre o tema que está estudando..." rows={1} className="max-h-45 min-h-11 w-full resize-none bg-transparent px-3 py-2.5 text-sm leading-6 outline-none placeholder:text-muted-foreground" />
        <div className="flex items-center justify-between gap-3 border-t px-1 pt-2">
          <Button type="button" variant="ghost" size="icon-sm" aria-label="Anexar arquivo (em breve)"><Paperclip className="size-4" aria-hidden="true" /></Button>
          <Button type="submit" size="sm" className="h-9" disabled={!draft.trim()}><Send className="size-4" aria-hidden="true" />Enviar</Button>
        </div>
      </form>
      <p className="mt-2 text-center text-xs text-muted-foreground">Interface demonstrativa — nenhuma mensagem é enviada a uma IA.</p>
    </div>
  );
}
